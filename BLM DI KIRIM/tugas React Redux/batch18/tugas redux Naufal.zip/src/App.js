import logo from "./logo.svg";
import "./App.css";
import EmployeeRedux from "./reduxList/employeeRedux";

function App() {
  return (
    <div>
      <EmployeeRedux />
    </div>
  );
}

export default App;
