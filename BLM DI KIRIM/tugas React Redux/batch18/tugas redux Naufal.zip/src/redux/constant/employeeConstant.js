export const get_employee = "get_employee";
export const add_employee = "add_employee";
export const add_salary = "add_salary";
export const reduce_salary = "reduce_salary";
